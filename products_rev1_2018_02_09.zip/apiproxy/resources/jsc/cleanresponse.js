var response = JSON.parse(context.getVariable("response.content"));

var clean = {"products": []};

if(typeof(response.documents) == 'undefined') {
    clean.products.push({"id": response.fields.id.integerValue, "description": response.fields.description.stringValue});
} else {
    for(var i=0;i<response.documents.length;i++) {
        clean.products.push({"id": response.documents[i].fields.id.integerValue, "description": response.documents[i].fields.description.stringValue});
    }
}

context.setVariable("response.content", JSON.stringify(clean));